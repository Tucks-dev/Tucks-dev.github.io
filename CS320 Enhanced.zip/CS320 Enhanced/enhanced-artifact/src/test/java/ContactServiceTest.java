package test;

import model.Contact;
import org.junit.jupiter.api.Test;
import service.ContactService;

import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    @Test
    void testAddAndRetrieveContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Street");

        service.addContact(contact);
        Contact retrieved = service.getContact("123");

        assertNotNull(retrieved);
        assertEquals("John", retrieved.getFirstName());
    }

    @Test
    void testInvalidContactThrowsException() {
        ContactService service = new ContactService();

        assertThrows(RuntimeException.class, () -> {
            service.addContact(null);
        });
    }
}