package service;

import exception.InvalidContactException;
import model.Contact;
import repository.ContactRepository;

public class ContactService {

    private final ContactRepository repository;

    public ContactService() {
        this.repository = new ContactRepository();
    }

    public void addContact(Contact contact) {
        validateContact(contact);
        repository.save(contact);
    }

    public Contact getContact(String id) {
        return repository.findById(id);
    }

    private void validateContact(Contact contact) {
        if (contact == null) {
            throw new InvalidContactException("Contact cannot be null");
        }
        if (contact.getContactID() == null || contact.getContactID().length() > 10) {
            throw new InvalidContactException("Invalid ID");
        }
    }
}