from dash import Dash, dcc, html, dash_table
import dash_leaflet as dl
from dash.dependencies import Input, Output
import plotly.express as px
import pandas as pd
import os

from animal_shelter import AnimalShelter


# Credentials
USERNAME = "aacuser"
PASSWORD = "SNHU1738"

shelter = AnimalShelter(USERNAME, PASSWORD)


# Centralized rescue filter definitions
RESCUE_FILTERS = {
    "water": {
        "animal_type": "Dog",
        "breed": {
            "$in": [
                "Labrador Retriever Mix",
                "Chesapeake Bay Retriever",
                "Newfoundland"
            ]
        },
        "sex_upon_outcome": "Intact Female",
        "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}
    },
    "mountain": {
        "animal_type": "Dog",
        "breed": {
            "$in": [
                "German Shepherd",
                "Alaskan Malamute",
                "Old English Sheepdog",
                "Siberian Husky",
                "Rottweiler"
            ]
        },
        "sex_upon_outcome": "Intact Male",
        "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}
    },
    "disaster": {
        "animal_type": "Dog",
        "breed": {
            "$in": [
                "Doberman Pinscher",
                "German Shepherd",
                "Golden Retriever",
                "Bloodhound",
                "Rottweiler"
            ]
        },
        "sex_upon_outcome": "Intact Male",
        "age_upon_outcome_in_weeks": {"$gte": 20, "$lte": 300}
    }
}


TABLE_FIELDS = {
    "_id": 0,
    "name": 1,
    "breed": 1,
    "animal_type": 1,
    "sex_upon_outcome": 1,
    "age_upon_outcome_in_weeks": 1,
    "location_lat": 1,
    "location_long": 1
}


def build_query(filter_type):
    return RESCUE_FILTERS.get(filter_type, {})


def get_local_records(filter_type):
    """
    Fallback for local testing when the original MongoDB host is unavailable.
    """
    sample_file = "sample_animals.csv"

    if not os.path.exists(sample_file):
        return []

    df_local = pd.read_csv(sample_file)

    if filter_type == "water":
        breeds = ["Labrador Retriever Mix", "Chesapeake Bay Retriever", "Newfoundland"]
        df_local = df_local[
            (df_local["animal_type"] == "Dog") &
            (df_local["breed"].isin(breeds)) &
            (df_local["sex_upon_outcome"] == "Intact Female") &
            (df_local["age_upon_outcome_in_weeks"].between(26, 156))
        ]
    elif filter_type == "mountain":
        breeds = ["German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"]
        df_local = df_local[
            (df_local["animal_type"] == "Dog") &
            (df_local["breed"].isin(breeds)) &
            (df_local["sex_upon_outcome"] == "Intact Male") &
            (df_local["age_upon_outcome_in_weeks"].between(26, 156))
        ]
    elif filter_type == "disaster":
        breeds = ["Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"]
        df_local = df_local[
            (df_local["animal_type"] == "Dog") &
            (df_local["breed"].isin(breeds)) &
            (df_local["sex_upon_outcome"] == "Intact Male") &
            (df_local["age_upon_outcome_in_weeks"].between(20, 300))
        ]

    return df_local.to_dict("records")


def get_table_records(filter_type):
    """
    Use MongoDB first, then local fallback if needed.
    """
    query = build_query(filter_type)
    records = shelter.read(query, TABLE_FIELDS)

    if records:
        return records

    return get_local_records(filter_type)


def get_top_breeds(filter_type):
    """
    Use MongoDB aggregation first, then local fallback if needed.
    """
    query = build_query(filter_type)

    pipeline = [
        {"$match": query},
        {"$group": {"_id": "$breed", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
        {"$limit": 5}
    ]

    results = shelter.aggregate(pipeline)
    if results:
        return results

    local_records = get_local_records(filter_type)
    if not local_records:
        return []

    df_local = pd.DataFrame(local_records)
    breed_counts = df_local["breed"].value_counts().head(5)

    return [{"_id": breed, "count": count} for breed, count in breed_counts.items()]


def default_dataframe():
    records = get_table_records("reset")
    if not records:
        return pd.DataFrame(columns=[
            "name",
            "breed",
            "animal_type",
            "sex_upon_outcome",
            "age_upon_outcome_in_weeks",
            "location_lat",
            "location_long"
        ])
    return pd.DataFrame.from_records(records)


df = default_dataframe()

app = Dash(__name__)

app.layout = html.Div([
    html.Center(html.H1("SNHU CS-340 Dashboard - Tucker Middleton")),
    html.Div([
        dcc.RadioItems(
            id='filter-type',
            options=[
                {'label': 'Water Rescue', 'value': 'water'},
                {'label': 'Mountain Rescue', 'value': 'mountain'},
                {'label': 'Disaster Rescue', 'value': 'disaster'},
                {'label': 'Reset', 'value': 'reset'}
            ],
            value='reset',
            labelStyle={'display': 'inline-block', 'margin-right': '15px'}
        )
    ], style={'padding': '10px'}),

    dash_table.DataTable(
        id='datatable-id',
        columns=[{"name": i, "id": i} for i in df.columns],
        data=df.to_dict('records'),
        page_size=10,
        filter_action="native",
        sort_action="native",
        row_selectable="single",
        selected_rows=[0],
        style_table={'overflowX': 'auto'},
        style_cell={
            'textAlign': 'left',
            'minWidth': '100px',
            'width': '150px',
            'maxWidth': '200px'
        },
    ),

    html.Div([
        dcc.Graph(id='pie-chart')
    ]),

    html.Div(id='map-id')
])


@app.callback(
    Output('datatable-id', 'data'),
    Input('filter-type', 'value')
)
def update_table(filter_value):
    records = get_table_records(filter_value)

    if not records:
        return []

    new_df = pd.DataFrame.from_records(records)
    return new_df.to_dict('records')


@app.callback(
    Output('pie-chart', 'figure'),
    Input('filter-type', 'value')
)
def update_pie(filter_value):
    top_breed_data = get_top_breeds(filter_value)

    if not top_breed_data:
        return px.pie(
            names=["No Data"],
            values=[1],
            title="Rescue Dog Breed Distribution"
        )

    labels = [item["_id"] for item in top_breed_data]
    values = [item["count"] for item in top_breed_data]

    fig = px.pie(
        names=labels,
        values=values,
        title="Rescue Dog Breed Distribution"
    )
    return fig


@app.callback(
    Output('map-id', "children"),
    [Input('datatable-id', "derived_virtual_data"),
     Input('datatable-id', "derived_virtual_selected_rows")]
)
def update_map(view_data, index):
    if not view_data:
        return dl.Map(
            style={'width': '1000px', 'height': '500px'},
            center=[30.75, -97.48],
            zoom=10
        )

    dff = pd.DataFrame.from_dict(view_data)

    if index is None or len(index) == 0:
        row = 0
    else:
        row = index[0]

    if row >= len(dff):
        return dl.Map(
            style={'width': '1000px', 'height': '500px'},
            center=[30.75, -97.48],
            zoom=10
        )

    return [
        dl.Map(
            style={'width': '1000px', 'height': '500px'},
            center=[dff.iloc[row]["location_lat"], dff.iloc[row]["location_long"]],
            zoom=10,
            children=[
                dl.TileLayer(id="base-layer-id"),
                dl.Marker(
                    position=[dff.iloc[row]["location_lat"], dff.iloc[row]["location_long"]],
                    children=[
                        dl.Tooltip(dff.iloc[row]["breed"]),
                        dl.Popup([
                            html.H1("Animal Name"),
                            html.P(dff.iloc[row]["name"])
                        ])
                    ]
                )
            ]
        )
    ]


if __name__ == "__main__":
    app.run(debug=True)