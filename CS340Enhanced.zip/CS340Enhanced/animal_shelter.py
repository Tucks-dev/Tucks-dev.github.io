from pymongo import MongoClient
import urllib.parse


class AnimalShelter:
    """
    CRUD operations for Animal collection in MongoDB
    """

    def __init__(self, username, password):
        # URL encode credentials
        user = urllib.parse.quote_plus(username)
        password = urllib.parse.quote_plus(password)

        host = 'nv-desktop-services.apporto.com'
        port = 31045
        database_name = 'AAC'
        collection_name = 'animals'

        self.client = MongoClient(f'mongodb://{user}:{password}@{host}:{port}')
        self.database = self.client[database_name]
        self.collection = self.database[collection_name]

    def create(self, data):
        """
        Insert a new document into the collection.
        Returns True if successful, False otherwise.
        """
        if not data:
            raise ValueError("Nothing to save, because data parameter is empty")

        try:
            self.collection.insert_one(data)
            return True
        except Exception as e:
            print(f"Create Error: {e}")
            return False

    def read(self, query=None, projection=None):
        """
        Query documents from the collection.
        Returns a list of matching documents.
        """
        if query is None:
            query = {}

        try:
            result = list(self.collection.find(query, projection))
            return result
        except Exception as e:
            print(f"Read Error: {e}")
            return []

    def update(self, query, new_values):
        """
        Update one or more documents that match the query.
        Returns the number of documents modified.
        """
        if not query or not new_values:
            raise ValueError("Query and new_values must both be provided.")

        try:
            result = self.collection.update_many(query, {'$set': new_values})
            return result.modified_count
        except Exception as e:
            print(f"Update Error: {e}")
            return 0

    def delete(self, query):
        """
        Delete one or more documents that match the query.
        Returns the number of documents deleted.
        """
        if not query:
            raise ValueError("Query parameter is required.")

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"Delete Error: {e}")
            return 0

    def aggregate(self, pipeline):
        """
        Run an aggregation pipeline on the collection.
        Returns a list of aggregation results.
        """
        if not pipeline:
            raise ValueError("Pipeline parameter is required.")

        try:
            return list(self.collection.aggregate(pipeline))
        except Exception as e:
            print(f"Aggregation Error: {e}")
            return []